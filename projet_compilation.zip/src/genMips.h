#ifndef __genMips__
#define __genMips__

#include "genCode.h"

/*
 * traduit le code 3 adresses en code mips
 * la fonction écrira le code dans le fichier de sorti directement
 */
void genMips(FILE* out);


#endif

